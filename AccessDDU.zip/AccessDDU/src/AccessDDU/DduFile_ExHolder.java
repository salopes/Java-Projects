package AccessDDU;

/**
 * DduFile_ExHolder.java
 */

public final class DduFile_ExHolder implements javax.xml.rpc.holders.Holder {
    public AccessDDU.DduFileEx value;

    public DduFile_ExHolder() {
    }

    public DduFile_ExHolder(AccessDDU.DduFileEx value) {
        this.value = value;
    }

}
