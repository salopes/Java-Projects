package AccessDDU;

import javax.xml.rpc.holders.Holder;

/**
 * DirFiles_ExHolder.java
 */

public final class DirFiles_ExHolder implements javax.xml.rpc.holders.Holder {
    public AccessDDU.DduFileEx[] value;

    public DirFiles_ExHolder() {
    }

    public DirFiles_ExHolder(AccessDDU.DduFileEx[] value) {
        this.value = value;
    }

}
